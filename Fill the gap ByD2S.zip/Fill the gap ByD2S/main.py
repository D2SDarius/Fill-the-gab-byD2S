import pygame
import random
import time

pygame.init()



Speed = 15
Width, height = 1250, 750
game_screen = pygame.display.set_mode((Width, height))
pygame.display.set_caption("Fill the Gab byD2S")
Gray = (169,169,169)
x, y = 400, 400
delta_x, delta_y = 10, 0

food_x, food_y = random.randrange(0 ,Width)//10*10, random.randrange(0 ,height)//10*10

game_over = False

font = pygame.font.SysFont('arial', 50)
font2 = pygame.font.SysFont('arial', 25)

body_list = [(x,y)]
score = font2.render("score=" + str(len(body_list)), True, (100, 100, 0))
clock = pygame.time.Clock()


def snake():
    global x, y, food_x , food_y, body_list, game_over, body_list
    x = (x + delta_x)%Width
    y = (y + delta_y)%height

    if((x,y) in body_list):
        game_over = True
        return

    body_list.append((x,y))

    if(food_x == x and food_y == y):
        while((food_x, food_y) in body_list):
            food_x, food_y = random.randrange(0, Width) // 10 * 10, random.randrange(0, height) // 10 * 10
    #else:
        #del body_list[0]

    game_screen.fill((Gray))
    score = font2.render("score=" + str(len(body_list)), True, (100, 100, 0))
    game_screen.blit(score, [Width // 6, height // 6])
    pygame.draw.rect(game_screen, (254, 100, 0), [food_x, food_y, 15, 15])
    for (i,j) in body_list:
        pygame.draw.rect(game_screen, (102, 153, 153), [i, j, 50, 50])
    #pygame.draw.rect(game_screen, (102, 153, 153), [x,y, 30, 30])
    pygame.display.update()

Buttons_presses = 0
button_press_right = 0
button_press_left = 0
button_press_up = 0
button_press_down = 0

while True:
    if(game_over):
        game_screen.fill((0, 0, 0))
        score = font2.render("score="+ str(len(body_list)), True, (100, 100, 0))
        msg = font.render("Game Over!", True, (255, 255, 255))
        game_screen.blit(msg, [Width//5, height//5])
        game_screen.blit(score, [Width//6, height//6])
        pygame.display.update()
        file = open("FTG_Logs.txt", "w")
        file.write("Score=" + str(len(body_list)) + "," + ("Speed_Player=" + str(Speed)) + "," + ("Buttons_presses=" + str(Buttons_presses)) + "," + ("Buttons_press_up=" + str(button_press_up)) + "," + ("Buttons_press_Down=" + str(button_press_down)) + "," + ("Button_press_left=" + str(button_press_left)) + "," + ("Button_press_right=" + str(button_press_right)))
        file.close()
        time.sleep(5)
        pygame.quit()
        quit()




    events = pygame.event.get()
    for event in events:
        if (event.type == pygame.QUIT):
            pygame.quit()
            quit()
        if (event.type == pygame.KEYDOWN):
            if (event.key == pygame.K_LEFT):
                if(delta_x != 10):
                    delta_x = -10
                    button_press_left += 1
                    Buttons_presses += 1
                delta_y = 0
            elif (event.key == pygame.K_RIGHT):
                if(delta_x != -10):
                    delta_x = 10
                    button_press_right += 1
                    Buttons_presses += 1
                delta_y = 0
            elif (event.key == pygame.K_UP):
                 delta_x = 0
                 if (delta_y != 10):
                     delta_y = -10
                     button_press_up+= 1
                     Buttons_presses += 1

            elif(event.key == pygame.K_DOWN):
                delta_x = 0
                if (delta_y != -10):
                    delta_y = 10
                    button_press_down += 1
                    Buttons_presses += 1
            elif(event.key == pygame.K_1):
                Speed += 15
            elif(event.key == pygame.K_2):
                Speed -= 15
                if (Speed == 0):
                    Speed += 15


            else:
                continue
            snake()
    if(not events):
        snake()
    clock.tick((Speed))

    print("score=" + str(len(body_list)))
    print("Speed_Player=" + str(Speed))
